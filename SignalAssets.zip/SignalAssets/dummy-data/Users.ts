export default [{
  id: 'u1',
  name: 'Vadim',
  imageUri: 'https://notjustdev-dummy.s3.us-east-2.amazonaws.com/avatars/vadim.jpg',
  status: "Hello there, how are you"
}, {
  id: 'u2',
  name: 'Elon Musk',
  imageUri: 'https://notjustdev-dummy.s3.us-east-2.amazonaws.com/avatars/elon.png',
}, {
  id: 'u3',
  name: 'Jeff',
  imageUri: 'https://notjustdev-dummy.s3.us-east-2.amazonaws.com/avatars/jeff.jpeg',
}, {
  id: 'u4',
  name: 'Zuck',
  imageUri: 'https://notjustdev-dummy.s3.us-east-2.amazonaws.com/avatars/zuck.jpeg',
}, {
  id: 'u5',
  name: 'Graham',
  imageUri: 'https://notjustdev-dummy.s3.us-east-2.amazonaws.com/avatars/graham.jpg',
}, {
  id: 'u6',
  name: 'Biahaze',
  imageUri: 'https://notjustdev-dummy.s3.us-east-2.amazonaws.com/avatars/biahaze.jpg',
}, {
  id: 'u7',
  name: 'Sus?',
  imageUri: 'https://notjustdev-dummy.s3.us-east-2.amazonaws.com/avatars/1.jpg',
}, {
  id: 'u8',
  name: 'Daniel',
  imageUri: 'https://notjustdev-dummy.s3.us-east-2.amazonaws.com/avatars/2.jpg',
}, {
  id: 'u9',
  name: 'Carlos',
  imageUri: 'https://notjustdev-dummy.s3.us-east-2.amazonaws.com/avatars/3.jpg',
}, {
  id: 'u10',
  name: 'Angelina Jolie',
  imageUri: 'https://notjustdev-dummy.s3.us-east-2.amazonaws.com/avatars/4.jpg',
}]
